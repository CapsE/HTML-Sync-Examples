window.prepareNormal = function() {
    var normal = new BABYLON.NormalMaterial("normal", scene);

    return normal;
};