#include "stdafx.h"
#include "FbxMeshHandler.h"


FbxMeshHandler::FbxMeshHandler()
{
}


FbxMeshHandler::~FbxMeshHandler()
{
}
